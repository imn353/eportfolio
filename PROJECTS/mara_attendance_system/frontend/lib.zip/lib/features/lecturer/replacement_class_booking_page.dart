import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/firestore/firestore_models.dart';
import '../../core/firestore/firestore_schema.dart';
import '../../core/providers/auth_provider.dart';
import '../../core/providers/metadata_provider.dart';
import '../../core/providers/replacement_session_provider.dart';
import '../../core/providers/timetable_provider.dart';
import '../notifications/widgets/notification_bell.dart';

class ReplacementClassBookingPage extends ConsumerStatefulWidget {
  const ReplacementClassBookingPage({super.key});

  @override
  ConsumerState<ReplacementClassBookingPage> createState() =>
      _ReplacementClassBookingPageState();
}

class _ReplacementClassBookingPageState
    extends ConsumerState<ReplacementClassBookingPage> {
  final _formKey = GlobalKey<FormState>();
  final _reasonController = TextEditingController();

  String? _selectedSubjectId;
  String? _selectedClassGroupId;
  String? _selectedRoomId;
  DateTime? _selectedDate;
  String? _selectedStartSlotId;
  String? _selectedEndSlotId;

  bool _isSaving = false;

  @override
  void dispose() {
    _reasonController.dispose();
    super.dispose();
  }

  String _formatDate(DateTime date) {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${days[date.weekday - 1]}, ${date.day} ${months[date.month - 1]} ${date.year}';
  }

  String _toDateString(DateTime date) {
    final y = date.year.toString();
    final m = date.month.toString().padLeft(2, '0');
    final d = date.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 30)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  /// Returns a conflict description string if there is an overlap, or null if clear.
  String? _checkConflict({
    required List<TimetableSessionModel> timetableSessions,
    required List<ReplacementSessionModel> replacementSessions,
    required List<TimeSlotModel> timeSlots,
    required String lecturerId,
    required String roomId,
    required String replacementDate,
    required String startSlotId,
    required String endSlotId,
  }) {
    final date = DateTime.parse(replacementDate);
    final dayOfWeek = date.weekday; // 1 = Monday … 7 = Sunday

    int slotNo(String id) => timeSlots
        .firstWhere(
          (s) => s.timeSlotId == id,
          orElse: () => TimeSlotModel(
            timeSlotId: id,
            slotNo: -1,
            startTime: '',
            endTime: '',
            durationMinutes: 0,
            status: '',
          ),
        )
        .slotNo;

    final newStart = slotNo(startSlotId);
    final newEnd = slotNo(endSlotId);

    bool overlaps(String aStart, String aEnd) {
      final aS = slotNo(aStart);
      final aE = slotNo(aEnd);
      return newStart <= aE && aS <= newEnd;
    }

    // Check against recurring timetable sessions on the same weekday
    for (final s in timetableSessions) {
      if (s.status.toLowerCase() != 'active') continue;
      if (s.dayOfWeek != dayOfWeek) continue;
      if (!overlaps(s.startSlotId, s.endSlotId)) continue;

      if (s.roomId == roomId) {
        return 'Room conflict: this room is already used at that time on ${_formatDate(date)}.';
      }
      if (s.lecturerId == lecturerId) {
        return 'Schedule conflict: you already have a class at that time on ${_formatDate(date)}.';
      }
    }

    // Check against other replacement sessions on the same date
    for (final s in replacementSessions) {
      if (s.replacementDate != replacementDate) continue;
      if (s.status == ReplacementSessionStatus.rejected.value) continue;
      if (s.status == ReplacementSessionStatus.cancelled.value) continue;
      if (!overlaps(s.startSlotId, s.endSlotId)) continue;

      if (s.roomId == roomId) {
        return 'Room conflict: this room already has a replacement class booked on ${_formatDate(date)}.';
      }
      if (s.lecturerId == lecturerId) {
        return 'Schedule conflict: you already have a replacement class at that time on ${_formatDate(date)}.';
      }
    }

    return null;
  }

  @override
  Widget build(BuildContext context) {
    // All ref.watch() at top level — required by Riverpod
    final subjectsState = ref.watch(subjectsProvider);
    final classGroupsState = ref.watch(classGroupsProvider);
    final roomsState = ref.watch(roomsProvider);
    final timeSlotsState = ref.watch(timeSlotsProvider);
    ref.watch(timetableSessionsProvider); // pre-warm for conflict check
    ref.watch(replacementSessionsProvider); // pre-warm for conflict check

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text(
          'Book Replacement Class',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Color(0xFF172033),
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF172033)),
        actions: const [NotificationBell()],
      ),
      body: subjectsState.when(
        data: (subjects) => classGroupsState.when(
          data: (classGroups) => roomsState.when(
            data: (rooms) => timeSlotsState.when(
              data: (timeSlots) => _buildForm(
                subjects: subjects,
                classGroups: classGroups,
                rooms: rooms,
                timeSlots: timeSlots,
              ),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, s) =>
                  Center(child: Text('Error loading time slots: $e')),
            ),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, s) => Center(child: Text('Error loading rooms: $e')),
          ),
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, s) =>
              Center(child: Text('Error loading class groups: $e')),
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, s) => Center(child: Text('Error loading subjects: $e')),
      ),
    );
  }

  Widget _buildForm({
    required List<SubjectModel> subjects,
    required List<ClassGroupModel> classGroups,
    required List<RoomModel> rooms,
    required List<TimeSlotModel> timeSlots,
  }) {
    final theme = Theme.of(context);

    final inputDecorationTheme = InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.withValues(alpha: 0.1)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.withValues(alpha: 0.1)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: theme.colorScheme.primary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.redAccent),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.redAccent, width: 1.5),
      ),
    );

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Form(
        key: _formKey,
        child: Theme(
          data: Theme.of(
            context,
          ).copyWith(inputDecorationTheme: inputDecorationTheme),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Subject
              DropdownButtonFormField<String>(
                initialValue: _selectedSubjectId,
                decoration: const InputDecoration(labelText: 'Subject'),
                items: subjects
                    .map(
                      (x) => DropdownMenuItem(
                        value: x.subjectId,
                        child: Text('${x.code} — ${x.name}'),
                      ),
                    )
                    .toList(),
                onChanged: (val) => setState(() => _selectedSubjectId = val),
                validator: (val) =>
                    val == null ? 'Please select a subject' : null,
              ),
              const SizedBox(height: 20),

              // Class Group
              DropdownButtonFormField<String>(
                initialValue: _selectedClassGroupId,
                decoration: const InputDecoration(labelText: 'Class Group'),
                items: classGroups
                    .map(
                      (x) => DropdownMenuItem(
                        value: x.classGroupId,
                        child: Text(x.name),
                      ),
                    )
                    .toList(),
                onChanged: (val) => setState(() => _selectedClassGroupId = val),
                validator: (val) =>
                    val == null ? 'Please select a class group' : null,
              ),
              const SizedBox(height: 20),

              // Room
              DropdownButtonFormField<String>(
                initialValue: _selectedRoomId,
                decoration: const InputDecoration(labelText: 'Room'),
                items: rooms
                    .map(
                      (x) => DropdownMenuItem(
                        value: x.roomId,
                        child: Text(x.name),
                      ),
                    )
                    .toList(),
                onChanged: (val) => setState(() => _selectedRoomId = val),
                validator: (val) => val == null ? 'Please select a room' : null,
              ),
              const SizedBox(height: 20),

              // Date Picker
              FormField<DateTime>(
                initialValue: _selectedDate,
                validator: (_) =>
                    _selectedDate == null ? 'Please select a date' : null,
                builder: (field) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    GestureDetector(
                      onTap: _pickDate,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 16,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: field.hasError
                                ? Colors.redAccent
                                : Colors.grey.withValues(alpha: 0.1),
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.calendar_today_outlined,
                              size: 18,
                              color: _selectedDate != null
                                  ? const Color(0xFF172033)
                                  : const Color(0xFF94A3B8),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              _selectedDate != null
                                  ? _formatDate(_selectedDate!)
                                  : 'Select Replacement Date',
                              style: TextStyle(
                                fontSize: 16,
                                color: _selectedDate != null
                                    ? const Color(0xFF172033)
                                    : const Color(0xFF94A3B8),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (field.hasError)
                      Padding(
                        padding: const EdgeInsets.only(top: 8, left: 12),
                        child: Text(
                          field.errorText!,
                          style: const TextStyle(
                            color: Colors.redAccent,
                            fontSize: 12,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Start Slot
              DropdownButtonFormField<String>(
                initialValue: _selectedStartSlotId,
                decoration: const InputDecoration(labelText: 'Start Slot'),
                items: timeSlots
                    .map(
                      (x) => DropdownMenuItem(
                        value: x.timeSlotId,
                        child: Text('Slot ${x.slotNo} — ${x.startTime}'),
                      ),
                    )
                    .toList(),
                onChanged: (val) => setState(() => _selectedStartSlotId = val),
                validator: (val) =>
                    val == null ? 'Please select a start slot' : null,
              ),
              const SizedBox(height: 20),

              // End Slot
              DropdownButtonFormField<String>(
                initialValue: _selectedEndSlotId,
                decoration: const InputDecoration(labelText: 'End Slot'),
                items: timeSlots
                    .map(
                      (x) => DropdownMenuItem(
                        value: x.timeSlotId,
                        child: Text('Slot ${x.slotNo} — ${x.endTime}'),
                      ),
                    )
                    .toList(),
                onChanged: (val) => setState(() => _selectedEndSlotId = val),
                validator: (val) =>
                    val == null ? 'Please select an end slot' : null,
              ),
              const SizedBox(height: 20),

              // Reason
              TextFormField(
                controller: _reasonController,
                decoration: const InputDecoration(
                  labelText: 'Reason for Replacement',
                  alignLabelWithHint: true,
                ),
                maxLines: 3,
                validator: (val) => (val == null || val.trim().isEmpty)
                    ? 'Please enter a reason'
                    : null,
              ),
              const SizedBox(height: 32),

              // Submit Button
              ElevatedButton(
                onPressed: _isSaving ? null : () => _submit(timeSlots),
                style: ElevatedButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: _isSaving
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : const Text(
                        'Submit for Approval',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _submit(List<TimeSlotModel> timeSlots) async {
    if (!_formKey.currentState!.validate()) return;

    final startSlot = timeSlots.firstWhere(
      (x) => x.timeSlotId == _selectedStartSlotId,
    );
    final endSlot = timeSlots.firstWhere(
      (x) => x.timeSlotId == _selectedEndSlotId,
    );

    if (startSlot.slotNo > endSlot.slotNo) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('End slot cannot be before the start slot.'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    final user = ref.read(authProvider);
    final lecturers = ref.read(lecturersProvider).value ?? [];
    final currentLecturer = lecturers.firstWhere(
      (l) => l.userUid == user?.uid,
      orElse: () => LecturerModel(
        lecturerId: '',
        userUid: '',
        fullName: '',
        email: '',
        status: '',
      ),
    );

    if (currentLecturer.lecturerId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No lecturer record found for your account.'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    // Overlap / conflict check
    final timetableSessions = ref.read(timetableSessionsProvider).value ?? [];
    final replacementSessions =
        ref.read(replacementSessionsProvider).value ?? [];
    final conflict = _checkConflict(
      timetableSessions: timetableSessions,
      replacementSessions: replacementSessions,
      timeSlots: timeSlots,
      lecturerId: currentLecturer.lecturerId,
      roomId: _selectedRoomId!,
      replacementDate: _toDateString(_selectedDate!),
      startSlotId: _selectedStartSlotId!,
      endSlotId: _selectedEndSlotId!,
    );

    if (conflict != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(conflict),
          backgroundColor: Colors.redAccent,
          duration: const Duration(seconds: 4),
        ),
      );
      return;
    }

    setState(() => _isSaving = true);

    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    try {
      await ref
          .read(replacementSessionServiceProvider)
          .createSession(
            lecturerId: currentLecturer.lecturerId,
            subjectId: _selectedSubjectId!,
            classGroupId: _selectedClassGroupId!,
            roomId: _selectedRoomId!,
            replacementDate: _toDateString(_selectedDate!),
            startSlotId: _selectedStartSlotId!,
            endSlotId: _selectedEndSlotId!,
            reason: _reasonController.text.trim(),
            createdByUid: user!.uid,
          );

      messenger.showSnackBar(
        const SnackBar(
          content: Text('Replacement class submitted for approval.'),
        ),
      );
      navigator.pop();
    } catch (e) {
      setState(() => _isSaving = false);
      messenger.showSnackBar(
        SnackBar(
          content: Text('Error submitting session: $e'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }
}
